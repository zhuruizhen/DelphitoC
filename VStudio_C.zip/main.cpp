#include "stdafx.h"
#include "CtoDelphi.h"

int main(void) {
	int retValue;
	WCHAR retStr[128];
	retValue = addNumbers(3,5);
	printf("Their sum is %d\n", retValue);
	
	cShowGetMessage(L"Hello",L"The Message", 128, retStr);
	printf("The return value is %S\n", retStr);
	getchar();
}