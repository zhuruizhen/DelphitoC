#include "stdafx.h"
#include "CtoDelphi.h"

static WCHAR* vstudioMessage = L"This is the message Microsoft Visual Studio returns:  \0\0";

int publicCInteger = 1234;
WCHAR* publicCArray = L"Message to be read from Delphi\0\0";

int addNumbers(int value1, int value2)
{
#ifdef DEBUGGING
	int myDelphiPublicIntVariable = 77;
#endif
  return value1 + value2 + myDelphiPublicIntVariable;
}

void cShowGetMessage (LPWSTR incaption, LPWSTR intext, int len, LPWSTR backToDelphiArray)
{
#ifdef DEBUGGING
	 WCHAR *myDelphiPublicStrVariable = L"I am a public Delphi string";
#endif
	WCHAR msgBuffer[0x100];
	wmemset((WCHAR*)msgBuffer, 0, 0x100);
	wcscpy_s((WCHAR*)msgBuffer, 0x100, vstudioMessage);
	wcscat_s(msgBuffer, 0x100, myDelphiPublicStrVariable);
#ifdef _WIN64
	MessageBoxW(0, msgBuffer, incaption, 0);
#else
	#ifndef DEBUGGING
		MessageBoxW2(0, msgBuffer, incaption, 0);
	#else

		MessageBoxW(0, intext, incaption, 0);
	#endif
#endif
	wmemset((WCHAR*)backToDelphiArray, 0, len);
	wcscpy_s((WCHAR*)backToDelphiArray, len, vstudioMessage);
	return;
}


