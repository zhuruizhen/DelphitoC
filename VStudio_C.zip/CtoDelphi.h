#pragma once
#include "stdafx.h"

#ifndef DEBUGGING
extern errno_t wcscpy_s(wchar_t *, size_t, const wchar_t *);
extern errno_t wcscat_s(wchar_t *strDestination, size_t numberOfElements, const wchar_t *strSource);

extern int myDelphiPublicIntVariable;
extern WCHAR *myDelphiPublicStrVariable;
#ifdef _WIN64
extern int MessageBoxW(HWND, LPCWSTR, LPCWSTR, UINT);
#else
extern int MessageBoxW2(HWND, LPCWSTR, LPCWSTR, UINT);
#endif
#endif

int addNumbers(int value1, int value2);
void cShowGetMessage (LPWSTR incaption, LPWSTR intext, int len, LPWSTR backToDelphiArray);
